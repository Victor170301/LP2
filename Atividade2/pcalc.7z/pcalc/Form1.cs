﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pcalc
{
    public partial class Form1 : Form
    {
        double n1, n2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void brnLimp_Click(object sender, EventArgs e)
        {
            txtN1.Clear();
            txtN2.Clear();
            txtResult.Clear();
        }

        private void txtN1_Validated(object sender, EventArgs e)
        {
            if (double.TryParse(txtN1.Text, out n1));
            {
            }
			

		}

        private void txtN2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtN2.Text, out n2)) { }
        }

        private void btnMais_Click(object sender, EventArgs e)
        {
            resultado = n1 + n2;
            txtResult.Text = resultado.ToString();
        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            resultado = n1 - n2;
            txtResult.Text = resultado.ToString();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = n1 * n2;
            txtResult.Text = resultado.ToString();
        }

        private void btnDivi_Click(object sender, EventArgs e)
        {
            if (n2 == 0)
            {
                MessageBox.Show("Não existe divisão por zero");
                txtN2.Focus();
            }
            else
            {
                resultado = n1 / n2;
                txtResult.Text = resultado.ToString();

            }
        }

        private void txtN1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
