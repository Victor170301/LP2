﻿namespace pcalc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
			this.lblN1 = new System.Windows.Forms.Label();
			this.lblN2 = new System.Windows.Forms.Label();
			this.lblResultado = new System.Windows.Forms.Label();
			this.txtN1 = new System.Windows.Forms.TextBox();
			this.txtResult = new System.Windows.Forms.TextBox();
			this.txtN2 = new System.Windows.Forms.TextBox();
			this.brnLimp = new System.Windows.Forms.Button();
			this.btnSair = new System.Windows.Forms.Button();
			this.btnMais = new System.Windows.Forms.Button();
			this.btnMenos = new System.Windows.Forms.Button();
			this.btnMult = new System.Windows.Forms.Button();
			this.btnDivi = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lblN1
			// 
			this.lblN1.AutoSize = true;
			this.lblN1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblN1.Location = new System.Drawing.Point(31, 37);
			this.lblN1.Name = "lblN1";
			this.lblN1.Size = new System.Drawing.Size(137, 32);
			this.lblN1.TabIndex = 0;
			this.lblN1.Text = "Número 1";
			// 
			// lblN2
			// 
			this.lblN2.AutoSize = true;
			this.lblN2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblN2.Location = new System.Drawing.Point(31, 146);
			this.lblN2.Name = "lblN2";
			this.lblN2.Size = new System.Drawing.Size(137, 32);
			this.lblN2.TabIndex = 1;
			this.lblN2.Text = "Número 2";
			// 
			// lblResultado
			// 
			this.lblResultado.AutoSize = true;
			this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblResultado.Location = new System.Drawing.Point(28, 255);
			this.lblResultado.Name = "lblResultado";
			this.lblResultado.Size = new System.Drawing.Size(143, 32);
			this.lblResultado.TabIndex = 2;
			this.lblResultado.Text = "Resultado";
			// 
			// txtN1
			// 
			this.txtN1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtN1.Location = new System.Drawing.Point(174, 30);
			this.txtN1.Name = "txtN1";
			this.txtN1.Size = new System.Drawing.Size(586, 39);
			this.txtN1.TabIndex = 3;
			this.txtN1.TextChanged += new System.EventHandler(this.txtN1_TextChanged);
			this.txtN1.Validated += new System.EventHandler(this.txtN1_Validated);
			// 
			// txtResult
			// 
			this.txtResult.Enabled = false;
			this.txtResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtResult.Location = new System.Drawing.Point(174, 252);
			this.txtResult.Name = "txtResult";
			this.txtResult.Size = new System.Drawing.Size(586, 39);
			this.txtResult.TabIndex = 4;
			// 
			// txtN2
			// 
			this.txtN2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtN2.Location = new System.Drawing.Point(174, 143);
			this.txtN2.Name = "txtN2";
			this.txtN2.Size = new System.Drawing.Size(586, 39);
			this.txtN2.TabIndex = 5;
			this.txtN2.Validated += new System.EventHandler(this.txtN2_Validated);
			// 
			// brnLimp
			// 
			this.brnLimp.Location = new System.Drawing.Point(558, 297);
			this.brnLimp.Name = "brnLimp";
			this.brnLimp.Size = new System.Drawing.Size(90, 59);
			this.brnLimp.TabIndex = 6;
			this.brnLimp.Text = "Limpar";
			this.brnLimp.UseVisualStyleBackColor = true;
			this.brnLimp.Click += new System.EventHandler(this.brnLimp_Click);
			// 
			// btnSair
			// 
			this.btnSair.Location = new System.Drawing.Point(654, 297);
			this.btnSair.Name = "btnSair";
			this.btnSair.Size = new System.Drawing.Size(90, 59);
			this.btnSair.TabIndex = 7;
			this.btnSair.Text = "Sair";
			this.btnSair.UseVisualStyleBackColor = true;
			this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
			// 
			// btnMais
			// 
			this.btnMais.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnMais.Location = new System.Drawing.Point(174, 81);
			this.btnMais.Name = "btnMais";
			this.btnMais.Size = new System.Drawing.Size(90, 59);
			this.btnMais.TabIndex = 8;
			this.btnMais.Text = "+";
			this.btnMais.UseVisualStyleBackColor = true;
			this.btnMais.Click += new System.EventHandler(this.btnMais_Click);
			// 
			// btnMenos
			// 
			this.btnMenos.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnMenos.Location = new System.Drawing.Point(270, 79);
			this.btnMenos.Name = "btnMenos";
			this.btnMenos.Size = new System.Drawing.Size(90, 59);
			this.btnMenos.TabIndex = 9;
			this.btnMenos.Text = "-";
			this.btnMenos.UseVisualStyleBackColor = true;
			this.btnMenos.Click += new System.EventHandler(this.btnMenos_Click);
			// 
			// btnMult
			// 
			this.btnMult.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnMult.Location = new System.Drawing.Point(366, 79);
			this.btnMult.Name = "btnMult";
			this.btnMult.Size = new System.Drawing.Size(90, 59);
			this.btnMult.TabIndex = 10;
			this.btnMult.Text = "*";
			this.btnMult.UseVisualStyleBackColor = true;
			this.btnMult.Click += new System.EventHandler(this.btnMult_Click);
			// 
			// btnDivi
			// 
			this.btnDivi.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnDivi.Location = new System.Drawing.Point(462, 79);
			this.btnDivi.Name = "btnDivi";
			this.btnDivi.Size = new System.Drawing.Size(90, 59);
			this.btnDivi.TabIndex = 11;
			this.btnDivi.Text = "/";
			this.btnDivi.UseVisualStyleBackColor = true;
			this.btnDivi.Click += new System.EventHandler(this.btnDivi_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 373);
			this.Controls.Add(this.btnDivi);
			this.Controls.Add(this.btnMult);
			this.Controls.Add(this.btnMenos);
			this.Controls.Add(this.btnMais);
			this.Controls.Add(this.btnSair);
			this.Controls.Add(this.brnLimp);
			this.Controls.Add(this.txtN2);
			this.Controls.Add(this.txtResult);
			this.Controls.Add(this.txtN1);
			this.Controls.Add(this.lblResultado);
			this.Controls.Add(this.lblN2);
			this.Controls.Add(this.lblN1);
			this.Name = "Form1";
			this.Text = "Calculadora";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblN1;
        private System.Windows.Forms.Label lblN2;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.TextBox txtN1;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.TextBox txtN2;
        private System.Windows.Forms.Button brnLimp;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnMais;
        private System.Windows.Forms.Button btnMenos;
        private System.Windows.Forms.Button btnMult;
        private System.Windows.Forms.Button btnDivi;
    }
}

