﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmexercicio4 : Form
    {
        public frmexercicio4()
        {
            InitializeComponent();
        }

        private void btnNumeros_Click(object sender, EventArgs e)
        {
            int contanum = 0;
            int contador = 0;

            while (contador<RchtxtTEXTAO.Text.Length)
            {
                if (char.IsNumber(RchtxtTEXTAO.Text[contador]))
                {
                    contanum++;
                }
                contador++;
            }
            MessageBox.Show("Qauntidade de numeros no texto: "+contanum);
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;

            for (int i = 0; i < RchtxtTEXTAO.TextLength; i++)
            {
                if (char.IsWhiteSpace(RchtxtTEXTAO.Text[i]))
                {
                    posicao = i + 1;
                    break;
                }

            }
            MessageBox.Show("posicão do primeiro caractere em brance é: " + posicao);
        }

        private void btnLetras_Click(object sender, EventArgs e)
        {
            int contaletra = 0;

            foreach(var c  in RchtxtTEXTAO.Text)
            {
                if (char.IsLetter(c))
                {
                    contaletra++;   
                }
            }
            MessageBox.Show("Quantidade letras é: "+contaletra);
        }   

    }
}
