﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmexercicio5 : Form
    {
        int n1, n2;
        public frmexercicio5()
        {
            InitializeComponent();
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtnum1.Clear();
            txtnum2.Clear();
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnrandom_Click(object sender, EventArgs e)
        {
            Random obj1 = new Random();
            int n1 = obj1.Next(0, 998);
            txtnum1.Text = n1.ToString();

            Random obj2 = new Random();
            int n2 = obj2.Next(n1+1, 1000);
            txtnum2.Text = n2.ToString();
        }
    }
}
