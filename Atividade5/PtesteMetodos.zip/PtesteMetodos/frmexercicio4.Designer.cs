﻿namespace PtesteMetodos
{
    partial class frmexercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RchtxtTEXTAO = new System.Windows.Forms.RichTextBox();
            this.btnBranco = new System.Windows.Forms.Button();
            this.btnLetras = new System.Windows.Forms.Button();
            this.btnNumeros = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // RchtxtTEXTAO
            // 
            this.RchtxtTEXTAO.Location = new System.Drawing.Point(12, 53);
            this.RchtxtTEXTAO.Name = "RchtxtTEXTAO";
            this.RchtxtTEXTAO.Size = new System.Drawing.Size(763, 218);
            this.RchtxtTEXTAO.TabIndex = 0;
            this.RchtxtTEXTAO.Text = "";
            // 
            // btnBranco
            // 
            this.btnBranco.Location = new System.Drawing.Point(340, 313);
            this.btnBranco.Name = "btnBranco";
            this.btnBranco.Size = new System.Drawing.Size(183, 86);
            this.btnBranco.TabIndex = 1;
            this.btnBranco.Text = "Primeiro espaço em branco";
            this.btnBranco.UseVisualStyleBackColor = true;
            this.btnBranco.Click += new System.EventHandler(this.btnBranco_Click);
            // 
            // btnLetras
            // 
            this.btnLetras.Location = new System.Drawing.Point(573, 313);
            this.btnLetras.Name = "btnLetras";
            this.btnLetras.Size = new System.Drawing.Size(183, 86);
            this.btnLetras.TabIndex = 2;
            this.btnLetras.Text = "Quantas letras";
            this.btnLetras.UseVisualStyleBackColor = true;
            this.btnLetras.Click += new System.EventHandler(this.btnLetras_Click);
            // 
            // btnNumeros
            // 
            this.btnNumeros.Location = new System.Drawing.Point(78, 313);
            this.btnNumeros.Name = "btnNumeros";
            this.btnNumeros.Size = new System.Drawing.Size(183, 86);
            this.btnNumeros.TabIndex = 3;
            this.btnNumeros.Text = "Quantos numeros";
            this.btnNumeros.UseVisualStyleBackColor = true;
            this.btnNumeros.Click += new System.EventHandler(this.btnNumeros_Click);
            // 
            // frmexercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnNumeros);
            this.Controls.Add(this.btnLetras);
            this.Controls.Add(this.btnBranco);
            this.Controls.Add(this.RchtxtTEXTAO);
            this.Name = "frmexercicio4";
            this.Text = "frmexercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox RchtxtTEXTAO;
        private System.Windows.Forms.Button btnBranco;
        private System.Windows.Forms.Button btnLetras;
        private System.Windows.Forms.Button btnNumeros;
    }
}