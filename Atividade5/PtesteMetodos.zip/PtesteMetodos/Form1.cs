﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Copiado");
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Colou o item");
        }

        private void exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmexercicio2>().Count() > 0)
            {
                MessageBox.Show("form já existe");
                Application.OpenForms["frmexercicio2"].BringToFront();
            }
            else
            {

                frmexercicio2 obj2 = new frmexercicio2();
                obj2.MdiParent = this;
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();
            }
        }

        private void exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmexercicio3>().Count() > 0)
            {
                MessageBox.Show("form já existe");
                Application.OpenForms["frmexercicio3"].BringToFront();
            }
            else
            {
                frmexercicio3 obj3 = new frmexercicio3();
                obj3.MdiParent = this;
                obj3.WindowState = FormWindowState.Maximized;
                obj3.Show();
            }
        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmexercicio4>().Count() > 0)
            {
                MessageBox.Show("form já existe");
                Application.OpenForms["frmexercicio4"].BringToFront();
            }
            else
            {
                frmexercicio4 obj4 = new frmexercicio4();
                obj4.MdiParent = this;
                obj4.WindowState = FormWindowState.Maximized;
                obj4.Show();
            }
        }

        private void exercicio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmexercicio5>().Count() > 0)
            {
                MessageBox.Show("form já existe");
                Application.OpenForms["frmexercicio5"].BringToFront();
            }
            else
            {
                frmexercicio5 obj5 = new frmexercicio5();
                obj5.MdiParent = this;
                obj5.WindowState = FormWindowState.Maximized;
                obj5.Show();
            }
        }
    }
}
