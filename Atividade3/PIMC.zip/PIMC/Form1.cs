﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Pimc : Form
    {
        double peso, altura, imc;
        public Pimc()
        {
            InitializeComponent();
        }

        private void BtnCalc_Click(object sender, EventArgs e)
        {
            imc = peso / Math.Pow(altura, 2);
            imc = Math.Round(imc, 1);
            txtimc.Text = imc.ToString();
            if (imc < 18.5)
            {
                MessageBox.Show("Magreza");
            }
            else if (imc <= 24.9)
            {
                MessageBox.Show("Normal");
            }
            else if (imc <= 29.9)
            {
                MessageBox.Show("Sobrepeso");
            }
            else if (imc <= 39.9)
            {
                MessageBox.Show("Obesidade");
            }
            else
            {
                MessageBox.Show("Obesidade grave");
            }
        }
        private void mskpeso_Validated(object sender, EventArgs e)
        {

            if (!double.TryParse(mskpeso.Text, out peso))
            {
            }
            if (peso <= 0)
            {
                MessageBox.Show("Peso não pode estar Zerado");
                mskpeso.Focus();
                mskpeso.Clear();
            }
        }

        private void mskaltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskaltura.Text, out altura))
            {
            }
            if (altura <= 0)
            {
                MessageBox.Show("Altura não pode estar Zerada");
                mskaltura.Focus();
                mskaltura.Clear();
            }
        }

        private void BtnLimp_Click(object sender, EventArgs e)
        {
            mskaltura.Clear();
            mskpeso.Clear();
            txtimc.Clear();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
           Close();
        }
    }
}
