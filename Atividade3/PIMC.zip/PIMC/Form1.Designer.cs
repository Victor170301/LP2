﻿namespace PIMC
{
    partial class Pimc
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Pimc));
            this.lblpeso = new System.Windows.Forms.Label();
            this.lblalt = new System.Windows.Forms.Label();
            this.lblimc = new System.Windows.Forms.Label();
            this.mskpeso = new System.Windows.Forms.MaskedTextBox();
            this.mskaltura = new System.Windows.Forms.MaskedTextBox();
            this.txtimc = new System.Windows.Forms.TextBox();
            this.BtnCalc = new System.Windows.Forms.Button();
            this.BtnLimp = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblpeso
            // 
            this.lblpeso.AutoSize = true;
            this.lblpeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpeso.Location = new System.Drawing.Point(76, 56);
            this.lblpeso.Name = "lblpeso";
            this.lblpeso.Size = new System.Drawing.Size(172, 37);
            this.lblpeso.TabIndex = 0;
            this.lblpeso.Text = "Peso Atual";
            // 
            // lblalt
            // 
            this.lblalt.AutoSize = true;
            this.lblalt.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblalt.Location = new System.Drawing.Point(146, 169);
            this.lblalt.Name = "lblalt";
            this.lblalt.Size = new System.Drawing.Size(102, 37);
            this.lblalt.TabIndex = 1;
            this.lblalt.Text = "Altura";
            // 
            // lblimc
            // 
            this.lblimc.AutoSize = true;
            this.lblimc.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblimc.Location = new System.Drawing.Point(174, 282);
            this.lblimc.Name = "lblimc";
            this.lblimc.Size = new System.Drawing.Size(74, 37);
            this.lblimc.TabIndex = 2;
            this.lblimc.Text = "IMC";
            // 
            // mskpeso
            // 
            this.mskpeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskpeso.Location = new System.Drawing.Point(275, 53);
            this.mskpeso.Mask = "900.00";
            this.mskpeso.Name = "mskpeso";
            this.mskpeso.Size = new System.Drawing.Size(486, 44);
            this.mskpeso.TabIndex = 3;
            this.mskpeso.Validated += new System.EventHandler(this.mskpeso_Validated);
            // 
            // mskaltura
            // 
            this.mskaltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskaltura.Location = new System.Drawing.Point(275, 162);
            this.mskaltura.Mask = "0.00";
            this.mskaltura.Name = "mskaltura";
            this.mskaltura.Size = new System.Drawing.Size(486, 44);
            this.mskaltura.TabIndex = 4;
            this.mskaltura.Validated += new System.EventHandler(this.mskaltura_Validated);
            // 
            // txtimc
            // 
            this.txtimc.Enabled = false;
            this.txtimc.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtimc.Location = new System.Drawing.Point(275, 275);
            this.txtimc.Name = "txtimc";
            this.txtimc.Size = new System.Drawing.Size(486, 44);
            this.txtimc.TabIndex = 5;
            // 
            // BtnCalc
            // 
            this.BtnCalc.Location = new System.Drawing.Point(61, 358);
            this.BtnCalc.Name = "BtnCalc";
            this.BtnCalc.Size = new System.Drawing.Size(180, 66);
            this.BtnCalc.TabIndex = 6;
            this.BtnCalc.Text = "Calcular";
            this.BtnCalc.UseVisualStyleBackColor = true;
            this.BtnCalc.Click += new System.EventHandler(this.BtnCalc_Click);
            // 
            // BtnLimp
            // 
            this.BtnLimp.Location = new System.Drawing.Point(319, 358);
            this.BtnLimp.Name = "BtnLimp";
            this.BtnLimp.Size = new System.Drawing.Size(180, 66);
            this.BtnLimp.TabIndex = 7;
            this.BtnLimp.Text = "Limpar";
            this.BtnLimp.UseVisualStyleBackColor = true;
            this.BtnLimp.Click += new System.EventHandler(this.BtnLimp_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.Location = new System.Drawing.Point(559, 358);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(180, 66);
            this.BtnSair.TabIndex = 8;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // Pimc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnLimp);
            this.Controls.Add(this.BtnCalc);
            this.Controls.Add(this.txtimc);
            this.Controls.Add(this.mskaltura);
            this.Controls.Add(this.mskpeso);
            this.Controls.Add(this.lblimc);
            this.Controls.Add(this.lblalt);
            this.Controls.Add(this.lblpeso);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Pimc";
            this.Text = "Pimc";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblpeso;
        private System.Windows.Forms.Label lblalt;
        private System.Windows.Forms.Label lblimc;
        private System.Windows.Forms.MaskedTextBox mskpeso;
        private System.Windows.Forms.MaskedTextBox mskaltura;
        private System.Windows.Forms.TextBox txtimc;
        private System.Windows.Forms.Button BtnCalc;
        private System.Windows.Forms.Button BtnLimp;
        private System.Windows.Forms.Button BtnSair;
    }
}

