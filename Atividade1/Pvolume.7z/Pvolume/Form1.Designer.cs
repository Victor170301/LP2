﻿namespace Pvolume
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
			this.lblraio = new System.Windows.Forms.Label();
			this.lblaltura = new System.Windows.Forms.Label();
			this.lblvolume = new System.Windows.Forms.Label();
			this.txtraio = new System.Windows.Forms.TextBox();
			this.txtaltura = new System.Windows.Forms.TextBox();
			this.txtvolume = new System.Windows.Forms.TextBox();
			this.btncalcular = new System.Windows.Forms.Button();
			this.btnfechar = new System.Windows.Forms.Button();
			this.btnlimpar = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lblraio
			// 
			this.lblraio.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.lblraio.AutoSize = true;
			this.lblraio.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblraio.Location = new System.Drawing.Point(43, 30);
			this.lblraio.Name = "lblraio";
			this.lblraio.Size = new System.Drawing.Size(82, 37);
			this.lblraio.TabIndex = 0;
			this.lblraio.Text = "Raio";
			this.lblraio.Click += new System.EventHandler(this.TxtRaio_Click);
			// 
			// lblaltura
			// 
			this.lblaltura.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.lblaltura.AutoSize = true;
			this.lblaltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblaltura.Location = new System.Drawing.Point(43, 99);
			this.lblaltura.Name = "lblaltura";
			this.lblaltura.Size = new System.Drawing.Size(102, 37);
			this.lblaltura.TabIndex = 1;
			this.lblaltura.Text = "Altura";
			// 
			// lblvolume
			// 
			this.lblvolume.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.lblvolume.AutoSize = true;
			this.lblvolume.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblvolume.Location = new System.Drawing.Point(43, 194);
			this.lblvolume.Name = "lblvolume";
			this.lblvolume.Size = new System.Drawing.Size(126, 37);
			this.lblvolume.TabIndex = 2;
			this.lblvolume.Text = "Volume";
			// 
			// txtraio
			// 
			this.txtraio.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.txtraio.Location = new System.Drawing.Point(145, 36);
			this.txtraio.Name = "txtraio";
			this.txtraio.Size = new System.Drawing.Size(625, 26);
			this.txtraio.TabIndex = 3;
			this.txtraio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.txtraio.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
			this.txtraio.Validated += new System.EventHandler(this.txtraio_Validated);
			// 
			// txtaltura
			// 
			this.txtaltura.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.txtaltura.Location = new System.Drawing.Point(145, 109);
			this.txtaltura.Name = "txtaltura";
			this.txtaltura.Size = new System.Drawing.Size(625, 26);
			this.txtaltura.TabIndex = 4;
			this.txtaltura.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.txtaltura.Validated += new System.EventHandler(this.txtaltura_Validated);
			// 
			// txtvolume
			// 
			this.txtvolume.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.txtvolume.Enabled = false;
			this.txtvolume.Location = new System.Drawing.Point(175, 205);
			this.txtvolume.Name = "txtvolume";
			this.txtvolume.Size = new System.Drawing.Size(595, 26);
			this.txtvolume.TabIndex = 5;
			// 
			// btncalcular
			// 
			this.btncalcular.Location = new System.Drawing.Point(50, 259);
			this.btncalcular.Name = "btncalcular";
			this.btncalcular.Size = new System.Drawing.Size(194, 74);
			this.btncalcular.TabIndex = 6;
			this.btncalcular.Text = "Calcular";
			this.btncalcular.UseVisualStyleBackColor = true;
			this.btncalcular.Click += new System.EventHandler(this.btncalcular_Click);
			// 
			// btnfechar
			// 
			this.btnfechar.Location = new System.Drawing.Point(576, 259);
			this.btnfechar.Name = "btnfechar";
			this.btnfechar.Size = new System.Drawing.Size(194, 74);
			this.btnfechar.TabIndex = 7;
			this.btnfechar.Text = "Fechar";
			this.btnfechar.UseVisualStyleBackColor = true;
			this.btnfechar.Click += new System.EventHandler(this.btnfechar_Click);
			// 
			// btnlimpar
			// 
			this.btnlimpar.Location = new System.Drawing.Point(327, 259);
			this.btnlimpar.Name = "btnlimpar";
			this.btnlimpar.Size = new System.Drawing.Size(194, 74);
			this.btnlimpar.TabIndex = 8;
			this.btnlimpar.Text = "Limpar";
			this.btnlimpar.UseVisualStyleBackColor = true;
			this.btnlimpar.Click += new System.EventHandler(this.btnlimpar_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 367);
			this.Controls.Add(this.btnlimpar);
			this.Controls.Add(this.btnfechar);
			this.Controls.Add(this.btncalcular);
			this.Controls.Add(this.txtvolume);
			this.Controls.Add(this.txtaltura);
			this.Controls.Add(this.txtraio);
			this.Controls.Add(this.lblvolume);
			this.Controls.Add(this.lblaltura);
			this.Controls.Add(this.lblraio);
			this.Name = "Form1";
			this.Text = "Cálculo De Volume";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblraio;
        private System.Windows.Forms.Label lblaltura;
        private System.Windows.Forms.Label lblvolume;
        private System.Windows.Forms.TextBox txtraio;
        private System.Windows.Forms.TextBox txtaltura;
        private System.Windows.Forms.TextBox txtvolume;
        private System.Windows.Forms.Button btncalcular;
        private System.Windows.Forms.Button btnfechar;
        private System.Windows.Forms.Button btnlimpar;
    }
}

