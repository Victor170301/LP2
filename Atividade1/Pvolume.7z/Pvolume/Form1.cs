﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvolume
{
    public partial class Form1 : Form
    {
        double raio, altura, volume;

        public Form1()
        {

            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void TxtRaio_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnfechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtraio.Text, out raio) ||
               (raio <= 0))

            {
                MessageBox.Show("Raio deve ser maior que zero!");

            }

            else if (!double.TryParse(txtaltura.Text, out altura) ||
                (altura <= 0))

            {
                MessageBox.Show("Altura deve ser maior que zero!");

            }
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtvolume.Clear();
            txtraio.Clear();
            txtaltura.Clear();
        }

        private void txtraio_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtraio.Text, out raio) ||
                (raio <= 0))

            {
                MessageBox.Show("Raio deve ser maior que zero!");

            }
        }


        private void txtaltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtaltura.Text, out altura) ||
                (altura <= 0))

            {
                MessageBox.Show("Altura deve ser maior que zero!");
                txtaltura.Focus();
            }
            else
            {
                volume = Math.PI * Math.Pow(raio, 2) *
                    altura;
                txtvolume.Text = volume.ToString("N2");
            }
        }
    }
}
