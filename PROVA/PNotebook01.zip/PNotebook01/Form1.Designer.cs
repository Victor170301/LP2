﻿namespace PNotebook01
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
			this.btnEXE = new System.Windows.Forms.Button();
			this.btnLMP = new System.Windows.Forms.Button();
			this.btnSR = new System.Windows.Forms.Button();
			this.listPRE = new System.Windows.Forms.ListBox();
			this.SuspendLayout();
			// 
			// btnEXE
			// 
			this.btnEXE.Location = new System.Drawing.Point(12, 12);
			this.btnEXE.Name = "btnEXE";
			this.btnEXE.Size = new System.Drawing.Size(193, 163);
			this.btnEXE.TabIndex = 0;
			this.btnEXE.Text = "EXECUTAR";
			this.btnEXE.UseVisualStyleBackColor = true;
			this.btnEXE.Click += new System.EventHandler(this.btnEXE_Click);
			// 
			// btnLMP
			// 
			this.btnLMP.Location = new System.Drawing.Point(12, 196);
			this.btnLMP.Name = "btnLMP";
			this.btnLMP.Size = new System.Drawing.Size(193, 163);
			this.btnLMP.TabIndex = 1;
			this.btnLMP.Text = "LIMPAR";
			this.btnLMP.UseVisualStyleBackColor = true;
			this.btnLMP.Click += new System.EventHandler(this.btnLMP_Click);
			// 
			// btnSR
			// 
			this.btnSR.Location = new System.Drawing.Point(12, 393);
			this.btnSR.Name = "btnSR";
			this.btnSR.Size = new System.Drawing.Size(193, 45);
			this.btnSR.TabIndex = 2;
			this.btnSR.Text = "SAIR";
			this.btnSR.UseVisualStyleBackColor = true;
			this.btnSR.Click += new System.EventHandler(this.btnSR_Click);
			// 
			// listPRE
			// 
			this.listPRE.FormattingEnabled = true;
			this.listPRE.ItemHeight = 20;
			this.listPRE.Location = new System.Drawing.Point(224, 12);
			this.listPRE.Name = "listPRE";
			this.listPRE.Size = new System.Drawing.Size(555, 424);
			this.listPRE.TabIndex = 3;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.listPRE);
			this.Controls.Add(this.btnSR);
			this.Controls.Add(this.btnLMP);
			this.Controls.Add(this.btnEXE);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnEXE;
        private System.Windows.Forms.Button btnLMP;
        private System.Windows.Forms.Button btnSR;
        private System.Windows.Forms.ListBox listPRE;
    }
}

