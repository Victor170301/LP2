﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PNotebook01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnEXE_Click(object sender, EventArgs e)
        {
            string[,] auxiliar = new string[3,3];
            double[,] value = new double[3, 3];






            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar[i,j] = Interaction.InputBox($"digite o valor do {i + 1}º notebook na {j + 1}ª loja");
                    value[i, j] = double.Parse(auxiliar[i,j]);


                }

               listPRE[0].add(10) 

			}

        }

        private void btnSR_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLMP_Click(object sender, EventArgs e)
        {
            listPRE.Items.Clear();
        }
    }
}
